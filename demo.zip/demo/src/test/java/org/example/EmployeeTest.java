package org.example;

import org.example.model.Employee;
import org.example.repository.EmployeeRepository;
import org.example.service.EmployeeService;
import org.example.service.EmployeeValidationException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
 class EmployeeTest {

    private static final int id = 0;

    @Autowired
    private EmployeeService service;

    @MockBean
    private EmployeeRepository employeerepository;

    @Test
    @DisplayName("Get All Employee Test")
    public void getallEmployeeTest() {
        when(employeerepository.findAll()).thenReturn((List<Employee>)(List<Employee>) Stream.of(new Employee(23, "neha", "KJ", 8978), new Employee(55, "sneha", "fd", 888888)).collect(Collectors.toList()));
        assertEquals(2, service.getEmployee().size());
    }

    @Test
    @DisplayName("Adding Employee Test")
    public void addEmployeeTest() throws EmployeeValidationException{
        Employee employee = new Employee(2345, "sona", "sd", 666666);
        int id = 0;
        service.addEmployee(employee);

    }

    @Test
    @DisplayName("Update Test")
    public void updateNameByIdTest() {
        Employee employee = new Employee(4567, "rani", "as", 777777);
        int id = 0;
        service.updateNameById(id, employee);

    }

    @Test
    @DisplayName("Delete Test")
    public void deleteByIdTest() {
        Employee employee = new Employee(8765, "usha", "ax", 999999);
        int id = 0;
        service.deleteEmployee(id);
        verify(employeerepository, times(1)).deleteById(id);
    }

}
package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;



@EnableDiscoveryClient
@SpringBootApplication
interface Exec{
	int ch(int n);
}
class lmp{
	public static int checker(Exec exec,int n){
		return exec.ch(n);
	}
	Exec vo(){
		Exec exec = (n) -> {return n%2;};
		return exec;
	}
}
public class EmployeeApplication {

	public static void main(String[] args) {
		lmp l = new lmp();
		Exec exec;
		int n=10,retval=0;
		String ans= null;
		exec = l.vo();
		retval = l.checker(exec,n);
		ans = (retval == 0)?"EN":"ON";
		System.out.println(ans);

		SpringApplication.run(EmployeeApplication.class, args);
	}
	
}



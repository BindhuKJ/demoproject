package org.example.service;

import java.util.List;

import org.example.model.Employee;


public interface EmployeeService1 {
	public String addEmployee(Employee employee) throws EmployeeValidationException;
	public List<Employee> getEmployee();



	public String deleteEmployee(int id);
	public Employee updateNameById(int id, Employee employee);
	
	}

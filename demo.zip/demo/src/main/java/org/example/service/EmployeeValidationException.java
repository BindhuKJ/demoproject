package org.example.service;

public class EmployeeValidationException extends Exception {




public static final long serialVersionUID = 1L;



public String message;


public EmployeeValidationException() {
super();
message = "Id not found";
}




public String getMessage(){

return message;
}
}

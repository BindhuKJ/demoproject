package org.example.service;

import java.util.List;


import org.example.model.Employee;


import org.example.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
@Component
public class EmployeeService implements EmployeeService1{
	
	

		private EmployeeRepository employeeRepository;
		EmployeeService employeeservice;

		@Autowired
		public EmployeeService(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
		}

		@Override
		public String addEmployee(Employee employee) throws EmployeeValidationException  {
			if (employeeRepository.existsById(employee.getId()))
				throw new EmployeeValidationException();
				else {  
		
			employeeRepository.save(employee);
			 return "Added employee with id:"+ employee.getId();
		}


		}
		
		@Override
		public String deleteEmployee(int id) {
			employeeRepository.deleteById(id);
		return "id deleted";



		}


		@Override
		public Employee updateNameById(int id, Employee employee) {
			return employeeRepository.save(employee);




		}



		@Override
		public List<Employee> getEmployee() {
			return employeeRepository.findAll();
			 
		
	
			

		}

		public void save(Employee employee) {
			// TODO Auto-generated method stub
			
		}


		}
